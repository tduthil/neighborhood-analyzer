"""
Neighborhood Analyzer Package
"""

# Basic empty __init__.py file to start